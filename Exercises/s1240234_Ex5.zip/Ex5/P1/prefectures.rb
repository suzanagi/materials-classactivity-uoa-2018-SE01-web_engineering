prefectures = ['Hokkaido', 'Aomori', 'Iwate', 'Miyagi', 'Akita', 'Yamagata', 'Fukushima', 'Ibaraki', 'Tochigi', 'Gunma' 'Nagano', 'Nagano', 'Nagano', 'Fukui', 'Nagano', 'Nagano', 'Saitama', 'Chiba', 'Gifu','Shizuoka','Aichi','Mie','Shiga','Kyoto','Osaka', 'Hyogo','Nara','Wakayama', 'Tottori','Shimane ','Okayama','Hiroshima','Yamaguchi','Tokushima','Kagawa','Ehime','Kochi','Fukuoka', 'Saga','Nagasaki','Kumamoto','Oita','Miyazaki','Kagoshima','Okinawa']
prefectures.sort! do |a, b|
  ret = a.casecmp(b)
  ret == 0 ? a <=> b : ret
end
p prefectures
